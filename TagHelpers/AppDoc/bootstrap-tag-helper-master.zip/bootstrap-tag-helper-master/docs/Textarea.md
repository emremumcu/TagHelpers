# Textarea

The textarea will be specified with a `<textarea>` tag and provides a multi-line text input field.

<img class="img-shadow img-responsive center-block" src="https://raw.githubusercontent.com/brecons/bootstrap-tag-helper/master/docs/images/textarea_01.PNG" width="334" alt="Bocons Textarea">

```markup
<textarea bc-label="Textarea Control"></textarea>
```